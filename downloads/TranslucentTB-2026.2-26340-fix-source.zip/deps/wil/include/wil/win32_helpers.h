//*********************************************************
//
//    Copyright (c) Microsoft. All rights reserved.
//    This code is licensed under the MIT License.
//    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
//    ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
//    TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
//    PARTICULAR PURPOSE AND NONINFRINGEMENT.
//
//*********************************************************
//! @file
//! Various types and helpers for interfacing with various Win32 APIs
#ifndef __WIL_WIN32_HELPERS_INCLUDED
#define __WIL_WIN32_HELPERS_INCLUDED

#include <minwindef.h>    // FILETIME, HINSTANCE
#include <sysinfoapi.h>   // GetSystemTimeAsFileTime
#include <libloaderapi.h> // GetProcAddress
#include <Psapi.h>        // GetModuleFileNameExW (macro), K32GetModuleFileNameExW
#include <winreg.h>
#include <objbase.h>

#include "common.h"

#if WIL_USE_STL
#include <string>
#if (__WI_LIBCPP_STD_VER >= 17) && WI_HAS_INCLUDE(<string_view>, 1) // Assume present if C++17
#include <string_view>
#endif
#if (__WI_LIBCPP_STD_VER >= 20)
#if WI_HAS_INCLUDE(<bit>, 1) // Assume present if C++20
#include <bit>
#endif
#if WI_HAS_INCLUDE(<compare>, 1) // Assume present if C++20
#include <compare>
#endif
#endif
#endif

/// @cond
#if WIL_USE_STL && (__cpp_lib_bit_cast >= 201806L)
#define __WI_CONSTEXPR_BIT_CAST constexpr
#else
#define __WI_CONSTEXPR_BIT_CAST // All uses are templates, which is implicitly inline
#endif
/// @endcond

#include "result.h"
#include "resource.h"
#include "wistd_functional.h"
#include "wistd_type_traits.h"

/// @cond
EXTERN_C IMAGE_DOS_HEADER __ImageBase;
/// @endcond

/// @cond
namespace wistd
{
#if WIL_USE_STL && (__cpp_lib_three_way_comparison >= 201907L)

using weak_ordering = std::weak_ordering;

#else

struct weak_ordering
{
    static const weak_ordering less;
    static const weak_ordering equivalent;
    static const weak_ordering greater;

    [[nodiscard]] friend constexpr bool operator==(const weak_ordering left, std::nullptr_t) noexcept
    {
        return left.m_value == 0;
    }

    [[nodiscard]] friend constexpr bool operator!=(const weak_ordering left, std::nullptr_t) noexcept
    {
        return left.m_value != 0;
    }

    [[nodiscard]] friend constexpr bool operator<(const weak_ordering left, std::nullptr_t) noexcept
    {
        return left.m_value < 0;
    }

    [[nodiscard]] friend constexpr bool operator>(const weak_ordering left, std::nullptr_t) noexcept
    {
        return left.m_value > 0;
    }

    [[nodiscard]] friend constexpr bool operator<=(const weak_ordering left, std::nullptr_t) noexcept
    {
        return left.m_value <= 0;
    }

    [[nodiscard]] friend constexpr bool operator>=(const weak_ordering left, std::nullptr_t) noexcept
    {
        return left.m_value >= 0;
    }

    [[nodiscard]] friend constexpr bool operator==(std::nullptr_t, const weak_ordering right) noexcept
    {
        return right == 0;
    }

    [[nodiscard]] friend constexpr bool operator!=(std::nullptr_t, const weak_ordering right) noexcept
    {
        return right != 0;
    }

    [[nodiscard]] friend constexpr bool operator<(std::nullptr_t, const weak_ordering right) noexcept
    {
        return right > 0;
    }

    [[nodiscard]] friend constexpr bool operator>(std::nullptr_t, const weak_ordering right) noexcept
    {
        return right < 0;
    }

    [[nodiscard]] friend constexpr bool operator<=(std::nullptr_t, const weak_ordering right) noexcept
    {
        return right >= 0;
    }

    [[nodiscard]] friend constexpr bool operator>=(std::nullptr_t, const weak_ordering right) noexcept
    {
        return right <= 0;
    }

    signed char m_value;
};

__WI_LIBCPP_INLINE_VAR constexpr weak_ordering weak_ordering::less{static_cast<signed char>(-1)};
__WI_LIBCPP_INLINE_VAR constexpr weak_ordering weak_ordering::equivalent{static_cast<signed char>(0)};
__WI_LIBCPP_INLINE_VAR constexpr weak_ordering weak_ordering::greater{static_cast<signed char>(1)};

#endif
} // namespace wistd
/// @endcond

namespace wil
{
//! Strictly a function of the file system but this is the value for all known file system, NTFS, FAT.
//! CDFs has a limit of 254.
constexpr size_t max_path_segment_length = 255;

//! Character length not including the null, MAX_PATH (260) includes the null.
constexpr size_t max_path_length = 259;

//! 32743 Character length not including the null. This is a system defined limit.
//! The 24 is for the expansion of the roots from "C:" to "\Device\HarddiskVolume4"
//! It will be 25 when there are more than 9 disks.
constexpr size_t max_extended_path_length = 0x7FFF - 24;

//! For {guid} string form. Includes space for the null terminator.
constexpr size_t guid_string_buffer_length = 39;

//! For {guid} string form. Not including the null terminator.
constexpr size_t guid_string_length = 38;

#pragma region String and identifier comparisons
// Using CompareStringOrdinal functions:
//
// Identifiers require a locale-less (ordinal), and often case-insensitive, comparison (filenames, registry keys, XML node names,
// etc). DO NOT use locale-sensitive (lexical) comparisons for resource identifiers (e.g. wcs*() functions in the CRT).

#if WIL_USE_STL && (__cpp_lib_string_view >= 201606L)
/// @cond
namespace details
{
    [[nodiscard]] inline int CompareStringOrdinal(std::wstring_view left, std::wstring_view right, bool caseInsensitive) WI_NOEXCEPT
    {
        // Casting from size_t (unsigned) to int (signed) should be safe from overrun to a negative,
        // merely truncating the string.  CompareStringOrdinal should be resilient to negatives.
        return ::CompareStringOrdinal(
            left.data(), static_cast<int>(left.size()), right.data(), static_cast<int>(right.size()), caseInsensitive);
    }
} // namespace details
/// @endcond

/** Performs an ordinal (locale-independent) comparison of two strings and returns their relative order.
Use ordinal comparisons for resource identifiers such as filenames, registry keys, and XML node names, where a locale-sensitive
(lexical) comparison would be incorrect. Wraps `CompareStringOrdinal`.
@param left The first string to compare.
@param right The second string to compare.
@param caseInsensitive `true` to compare without regard to case; `false` for a case-sensitive comparison.
@return A `wistd::weak_ordering` that is `less`, `equivalent`, or `greater` for `left` relative to `right`. */
[[nodiscard]] inline wistd::weak_ordering compare_string_ordinal(std::wstring_view left, std::wstring_view right, bool caseInsensitive) WI_NOEXCEPT
{
    switch (wil::details::CompareStringOrdinal(left, right, caseInsensitive))
    {
    case CSTR_LESS_THAN:
        return wistd::weak_ordering::less;
    case CSTR_GREATER_THAN:
        return wistd::weak_ordering::greater;
    default:
        return wistd::weak_ordering::equivalent;
    }
}
#endif

#pragma endregion

#pragma region FILETIME helpers
//! Common FILETIME durations, expressed in the 100-nanosecond units that `FILETIME` uses.
namespace filetime_duration
{
    //! One millisecond, in 100-nanosecond units.
    long long const one_millisecond = 10000LL;
    //! One second, in 100-nanosecond units.
    long long const one_second = 10000000LL;
    //! One minute, in 100-nanosecond units.
    long long const one_minute = 10000000LL * 60;        // 600000000    or 600000000LL
    //! One hour, in 100-nanosecond units.
    long long const one_hour = 10000000LL * 60 * 60;     // 36000000000  or 36000000000LL
    //! One day, in 100-nanosecond units.
    long long const one_day = 10000000LL * 60 * 60 * 24; // 864000000000 or 864000000000LL
}; // namespace filetime_duration

namespace filetime
{
    /// Reinterprets a `FILETIME` as a 64-bit integer count of 100-nanosecond units.
    /// @tparam Int64 A 64-bit integral type to return the value as; defaults to `unsigned long long`.
    /// @param val The `FILETIME` to convert.
    /// @return The `FILETIME` reinterpreted as a single 64-bit integer.
    template <typename Int64 = unsigned long long, wistd::enable_if_t<wistd::is_integral_v<Int64> && (sizeof(Int64) == sizeof(FILETIME)), int> = 0>
    constexpr Int64 to_int64(const FILETIME& val) WI_NOEXCEPT
    {
#if WIL_USE_STL && (__cpp_lib_bit_cast >= 201806L)
        return std::bit_cast<Int64>(val);
#else
        // Cannot reinterpret_cast FILETIME* to Int64* due to alignment differences.
        return (static_cast<Int64>(val.dwHighDateTime) << 32) + val.dwLowDateTime;
#endif
    }

    /// @cond
    namespace details
    {
        template <typename Int>
        using select_int64 =
            wistd::conditional_t<sizeof(Int) == 8, Int, wistd::conditional_t<wistd::is_signed_v<Int>, long long, unsigned long long>>;
    }
    /// @endcond

    /// Converts an integer count of 100-nanosecond units into a `FILETIME`.
    /// @tparam Int An integral type no larger than `FILETIME` (8 bytes).
    /// @param val The 100-nanosecond count to convert.
    /// @return A `FILETIME` representing the given count.
    template <typename Int, wistd::enable_if_t<wistd::is_integral_v<Int> && (sizeof(Int) <= sizeof(FILETIME)), int> = 0>
    __WI_CONSTEXPR_BIT_CAST FILETIME from_int64(Int val) WI_NOEXCEPT
    {
        using Int64 = details::select_int64<Int>;
        auto i64 = static_cast<Int64>(val);

#if WIL_USE_STL && (__cpp_lib_bit_cast >= 201806L)
        return std::bit_cast<FILETIME>(i64);
#else
        static_assert(sizeof(i64) == sizeof(FILETIME), "sizes don't match");
        static_assert(__alignof(Int64) >= __alignof(FILETIME), "alignment not compatible with type pun");
        return *reinterpret_cast<FILETIME*>(&i64);
#endif
    }

    /// Adds a 100-nanosecond delta to a `FILETIME` and returns the resulting time.
    /// @tparam Int An integral type no larger than `FILETIME` (8 bytes).
    /// @param baseTime The starting time.
    /// @param delta100ns The number of 100-nanosecond units to add (negative values move backwards in time).
    /// @return `baseTime` advanced by `delta100ns`, as a new `FILETIME`.
    template <typename Int, wistd::enable_if_t<wistd::is_integral_v<Int> && (sizeof(Int) <= sizeof(FILETIME)), int> = 0>
    __WI_CONSTEXPR_BIT_CAST FILETIME add(FILETIME const& baseTime, Int delta100ns) WI_NOEXCEPT
    {
        using Int64 = details::select_int64<Int>;
        return from_int64(to_int64<Int64>(baseTime) + delta100ns);
    }

    /// Returns whether a `FILETIME` is zero (both `dwHighDateTime` and `dwLowDateTime` are 0).
    /// @param val The `FILETIME` to test.
    /// @return `true` if `val` is all zero, `false` otherwise.
    constexpr bool is_empty(const FILETIME& val) WI_NOEXCEPT
    {
        return (val.dwHighDateTime == 0) && (val.dwLowDateTime == 0);
    }

    /// Returns the current system time (UTC) as a `FILETIME`, via `GetSystemTimeAsFileTime`.
    /// @return The current system time.
    inline FILETIME get_system_time() WI_NOEXCEPT
    {
        FILETIME now;
        GetSystemTimeAsFileTime(&now);
        return now;
    }

    /// Convert time as units of 100 nanoseconds to milliseconds. Fractional milliseconds are truncated.
    constexpr unsigned long long convert_100ns_to_msec(unsigned long long time100ns) WI_NOEXCEPT
    {
        return time100ns / filetime_duration::one_millisecond;
    }

    /// Convert time as milliseconds to units of 100 nanoseconds.
    constexpr unsigned long long convert_msec_to_100ns(unsigned long long timeMsec) WI_NOEXCEPT
    {
        return timeMsec * filetime_duration::one_millisecond;
    }

#if (defined(_APISETREALTIME_) && (_WIN32_WINNT >= _WIN32_WINNT_WIN7)) || defined(WIL_DOXYGEN)
    /// Returns the current unbiased interrupt-time count, in units of 100 nanoseconds. The unbiased interrupt-time count does not
    /// include time the system spends in sleep or hibernation.
    ///
    /// This API avoids prematurely shortcircuiting timing loops due to system sleep/hibernation.
    ///
    /// This is equivalent to GetTickCount64() except it returns units of 100 nanoseconds instead of milliseconds, and it doesn't
    /// include time the system spends in sleep or hibernation.
    /// For example
    ///
    ///     start = GetTickCount64();
    ///     hibernate();
    ///     ...wake from hibernation 30 minutes later...;
    ///     elapsed = GetTickCount64() - start;
    ///     // elapsed = 30min
    ///
    /// Do the same using unbiased interrupt-time and elapsed is 0 (or nearly so).
    ///
    /// @note This is identical to QueryUnbiasedInterruptTime() but returns the value as a return value (rather than an out
    ///       parameter).
    /// @see https://msdn.microsoft.com/en-us/library/windows/desktop/ee662307(v=vs.85).aspx
    inline unsigned long long QueryUnbiasedInterruptTimeAs100ns() WI_NOEXCEPT
    {
        ULONGLONG now{};
        QueryUnbiasedInterruptTime(&now);
        return now;
    }

    /// Returns the current unbiased interrupt-time count, in units of milliseconds. The unbiased interrupt-time count does not
    /// include time the system spends in sleep or hibernation.
    /// @see QueryUnbiasedInterruptTimeAs100ns
    inline unsigned long long QueryUnbiasedInterruptTimeAsMSec() WI_NOEXCEPT
    {
        return convert_100ns_to_msec(QueryUnbiasedInterruptTimeAs100ns());
    }
#endif // _APISETREALTIME_
} // namespace filetime
#pragma endregion

#pragma region RECT helpers
/** Returns the width of a rectangle (its `right` minus `left`).
@tparam rect_type A rectangle type with `left` and `right` members (e.g. `RECT`).
@param rect The rectangle to measure.
@return The width, computed as `rect.right - rect.left`. */
template <typename rect_type>
constexpr auto rect_width(rect_type const& rect)
{
    return rect.right - rect.left;
}

/** Returns the height of a rectangle (its `bottom` minus `top`).
@tparam rect_type A rectangle type with `top` and `bottom` members (e.g. `RECT`).
@param rect The rectangle to measure.
@return The height, computed as `rect.bottom - rect.top`. */
template <typename rect_type>
constexpr auto rect_height(rect_type const& rect)
{
    return rect.bottom - rect.top;
}

/** Returns whether a rectangle is empty (encloses no area).
@tparam rect_type A rectangle type with `left`, `top`, `right`, and `bottom` members (e.g. `RECT`).
@param rect The rectangle to test.
@return `true` if the rectangle is empty (`left >= right` or `top >= bottom`), `false` otherwise. */
template <typename rect_type>
constexpr auto rect_is_empty(rect_type const& rect)
{
    return (rect.left >= rect.right) || (rect.top >= rect.bottom);
}

/** Returns whether a point lies within a rectangle, treating the rectangle as half-open.
The `left` and `top` edges are inclusive while the `right` and `bottom` edges are exclusive.
@tparam rect_type A rectangle type with `left`, `top`, `right`, and `bottom` members (e.g. `RECT`).
@tparam point_type A point type with `x` and `y` members (e.g. `POINT`).
@param rect The rectangle to test against.
@param point The point to test.
@return `true` if `point` is inside `rect`, `false` otherwise. */
template <typename rect_type, typename point_type>
constexpr auto rect_contains_point(rect_type const& rect, point_type const& point)
{
    return (point.x >= rect.left) && (point.x < rect.right) && (point.y >= rect.top) && (point.y < rect.bottom);
}

/** Builds a rectangle from an origin and a size.
@tparam rect_type A rectangle type with `left`, `top`, `right`, and `bottom` members (e.g. `RECT`).
@tparam length_type The integral type of the coordinate and size values.
@param x The left coordinate of the rectangle.
@param y The top coordinate of the rectangle.
@param width The width of the rectangle; `right` is set to `x + width`.
@param height The height of the rectangle; `bottom` is set to `y + height`.
@return A `rect_type` with the given origin and size. */
template <typename rect_type, typename length_type>
constexpr rect_type rect_from_size(length_type x, length_type y, length_type width, length_type height)
{
    rect_type rect;
    rect.left = x;
    rect.top = y;
    rect.right = x + width;
    rect.bottom = y + height;
    return rect;
}
#pragma endregion

/** Adapts a Win32 API that fills a fixed-size, caller-provided buffer into one that returns an allocated string.
Many Win32 APIs write into a fixed-size buffer and report how much space is required. This helper first tries a stack buffer of
`stackBufferLength` characters and, if that is too small, allocates a buffer of the required size, retrying if the required size
changes between calls. Supports any `string_type` understood by the internal `string_maker` (e.g. `wil::unique_cotaskmem_string`
or `std::wstring`).
~~~
// Wrap a fixed-size Win32 API (here ::GetSystemDirectoryW) into one that returns an allocated string.
wil::unique_cotaskmem_string dir;
RETURN_IF_FAILED(wil::AdaptFixedSizeToAllocatedResult(dir,
    [](PWSTR value, size_t valueLength, size_t* valueLengthNeededWithNul) -> HRESULT
    {
        *valueLengthNeededWithNul = ::GetSystemDirectoryW(value, static_cast<DWORD>(valueLength));
        RETURN_LAST_ERROR_IF(*valueLengthNeededWithNul == 0);
        if (*valueLengthNeededWithNul < valueLength)
        {
            (*valueLengthNeededWithNul)++; // it fit; account for the null
        }
        return S_OK;
    }));
~~~
@tparam string_type The string type to produce the result in.
@tparam stackBufferLength The size, in characters, of the initial stack buffer; tune it to typical result sizes.
@param result Receives the resulting string on success.
@param callback Invoked to fill the buffer. It is passed the buffer, the buffer length in characters, and an out pointer that it
        must set to the number of characters needed including the null terminator. It returns an `HRESULT`, and any failure is
        propagated to the caller.
@return `S_OK` on success, or a failure `HRESULT` from `callback` or from allocation. */
template <typename string_type, size_t stackBufferLength = 256>
HRESULT AdaptFixedSizeToAllocatedResult(string_type& result, const wistd::function<HRESULT(PWSTR, size_t, size_t*)>& callback) WI_NOEXCEPT
{
    details::string_maker<string_type> maker;

    wchar_t value[stackBufferLength]{};
    size_t valueLengthNeededWithNull{}; // callback returns the number of characters needed including the null terminator.
    RETURN_IF_FAILED_EXPECTED(callback(value, ARRAYSIZE(value), &valueLengthNeededWithNull));
    WI_ASSERT(valueLengthNeededWithNull > 0);
    if (valueLengthNeededWithNull <= ARRAYSIZE(value))
    {
        // Success case as described above, make() adds the space for the null.
        RETURN_IF_FAILED(maker.make(value, valueLengthNeededWithNull - 1));
    }
    else
    {
        // Did not fit in the stack allocated buffer, need to do 2 phase construction.
        // May need to loop more than once if external conditions cause the value to change.
        size_t bufferLength;
        do
        {
            bufferLength = valueLengthNeededWithNull;
            // bufferLength includes the null so subtract that as make() will add space for it.
            RETURN_IF_FAILED(maker.make(nullptr, bufferLength - 1));

            RETURN_IF_FAILED_EXPECTED(callback(maker.buffer(), bufferLength, &valueLengthNeededWithNull));
            WI_ASSERT(valueLengthNeededWithNull > 0);

            // If the value shrunk, then adjust the string to trim off the excess buffer.
            if (valueLengthNeededWithNull < bufferLength)
            {
                RETURN_IF_FAILED(maker.trim_at_existing_null(valueLengthNeededWithNull - 1));
            }
        } while (valueLengthNeededWithNull > bufferLength);
    }
    result = maker.release();
    return S_OK;
}

/** Expands the '%' quoted environment variables in 'input' using ExpandEnvironmentStringsW(); */
template <typename string_type, size_t stackBufferLength = 256>
HRESULT ExpandEnvironmentStringsW(_In_ PCWSTR input, string_type& result) WI_NOEXCEPT
{
    return wil::AdaptFixedSizeToAllocatedResult<string_type, stackBufferLength>(
        result, [&](_Out_writes_(valueLength) PWSTR value, size_t valueLength, _Out_ size_t* valueLengthNeededWithNul) -> HRESULT {
            *valueLengthNeededWithNul = ::ExpandEnvironmentStringsW(input, value, static_cast<DWORD>(valueLength));
            RETURN_LAST_ERROR_IF(*valueLengthNeededWithNul == 0);
            return S_OK;
        });
}

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)
/** Searches for a specified file in a specified path using SearchPathW(). */
template <typename string_type, size_t stackBufferLength = 256>
HRESULT SearchPathW(_In_opt_ PCWSTR path, _In_ PCWSTR fileName, _In_opt_ PCWSTR extension, string_type& result) WI_NOEXCEPT
{
    return wil::AdaptFixedSizeToAllocatedResult<string_type, stackBufferLength>(
        result, [&](_Out_writes_(valueLength) PWSTR value, size_t valueLength, _Out_ size_t* valueLengthNeededWithNul) -> HRESULT {
            *valueLengthNeededWithNul = ::SearchPathW(path, fileName, extension, static_cast<DWORD>(valueLength), value, nullptr);

            if (*valueLengthNeededWithNul == 0)
            {
                // ERROR_FILE_NOT_FOUND is an expected return value for SearchPathW
                const HRESULT searchResult = HRESULT_FROM_WIN32(::GetLastError());
                RETURN_HR_IF_EXPECTED(searchResult, searchResult == HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND));
                RETURN_IF_FAILED(searchResult);
            }

            // AdaptFixedSizeToAllocatedResult expects that the length will always include the NUL.
            // If the result is copied to the buffer, SearchPathW returns the length of copied string, WITHOUT the NUL.
            // If the buffer is too small to hold the result, SearchPathW returns the length of the required buffer WITH the nul.
            if (*valueLengthNeededWithNul < valueLength)
            {
                (*valueLengthNeededWithNul)++; // It fit, account for the null.
            }
            return S_OK;
        });
}

/** Retrieves the full path of the executable image for the specified process, using `QueryFullProcessImageNameW`.
@tparam string_type The string type to produce the result in.
@tparam stackBufferLength The size, in characters, of the initial stack buffer.
@param processHandle A handle to the process, opened with `PROCESS_QUERY_INFORMATION` or `PROCESS_QUERY_LIMITED_INFORMATION`
        access.
@param flags Passed through to `QueryFullProcessImageNameW`; `0` for the Win32 path form or `PROCESS_NAME_NATIVE` for the native
        path form.
@param result Receives the image path on success.
@return `S_OK` on success, or a failure `HRESULT`. */
template <typename string_type, size_t stackBufferLength = 256>
HRESULT QueryFullProcessImageNameW(HANDLE processHandle, _In_ DWORD flags, string_type& result) WI_NOEXCEPT
{
    return wil::AdaptFixedSizeToAllocatedResult<string_type, stackBufferLength>(
        result, [&](_Out_writes_(valueLength) PWSTR value, size_t valueLength, _Out_ size_t* valueLengthNeededWithNul) -> HRESULT {
            DWORD lengthToUse = static_cast<DWORD>(valueLength);
            BOOL const success = ::QueryFullProcessImageNameW(processHandle, flags, value, &lengthToUse);
            RETURN_LAST_ERROR_IF((success == FALSE) && (::GetLastError() != ERROR_INSUFFICIENT_BUFFER));

            // On success, return the amount used; on failure, try doubling
            *valueLengthNeededWithNul = success ? (static_cast<size_t>(lengthToUse) + 1) : (static_cast<size_t>(lengthToUse) * 2);
            return S_OK;
        });
}

/** Expands environment strings and checks path existence with SearchPathW */
template <typename string_type, size_t stackBufferLength = 256>
HRESULT ExpandEnvAndSearchPath(_In_ PCWSTR input, string_type& result) WI_NOEXCEPT
{
    wil::unique_cotaskmem_string expandedName;
    RETURN_IF_FAILED((wil::ExpandEnvironmentStringsW<string_type, stackBufferLength>(input, expandedName)));

    // ERROR_FILE_NOT_FOUND is an expected return value for SearchPathW
    const HRESULT searchResult = (wil::SearchPathW<string_type, stackBufferLength>(nullptr, expandedName.get(), nullptr, result));
    RETURN_HR_IF_EXPECTED(searchResult, searchResult == HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND));
    RETURN_IF_FAILED(searchResult);

    return S_OK;
}
#endif

/** Looks up the environment variable 'key' and fails if it is not found. */
template <typename string_type, size_t initialBufferLength = 128>
inline HRESULT GetEnvironmentVariableW(_In_ PCWSTR key, string_type& result) WI_NOEXCEPT
{
    return wil::AdaptFixedSizeToAllocatedResult<string_type, initialBufferLength>(
        result, [&](_Out_writes_(valueLength) PWSTR value, size_t valueLength, _Out_ size_t* valueLengthNeededWithNul) -> HRESULT {
            // If the function succeeds, the return value is the number of characters stored in the buffer
            // pointed to by lpBuffer, not including the terminating null character.
            //
            // If lpBuffer is not large enough to hold the data, the return value is the buffer size, in
            // characters, required to hold the string and its terminating null character and the contents of
            // lpBuffer are undefined.
            //
            // If the function fails, the return value is zero. If the specified environment variable was not
            // found in the environment block, GetLastError returns ERROR_ENVVAR_NOT_FOUND.

            ::SetLastError(ERROR_SUCCESS);

            *valueLengthNeededWithNul = ::GetEnvironmentVariableW(key, value, static_cast<DWORD>(valueLength));
            RETURN_LAST_ERROR_IF_EXPECTED((*valueLengthNeededWithNul == 0) && (::GetLastError() != ERROR_SUCCESS));
            if (*valueLengthNeededWithNul < valueLength)
            {
                (*valueLengthNeededWithNul)++; // It fit, account for the null.
            }
            return S_OK;
        });
}

/** Looks up the environment variable 'key' and returns null if it is not found. */
template <typename string_type, size_t initialBufferLength = 128>
HRESULT TryGetEnvironmentVariableW(_In_ PCWSTR key, string_type& result) WI_NOEXCEPT
{
    const auto hr = wil::GetEnvironmentVariableW<string_type, initialBufferLength>(key, result);
    RETURN_HR_IF(hr, FAILED(hr) && (hr != HRESULT_FROM_WIN32(ERROR_ENVVAR_NOT_FOUND)));
    return S_OK;
}

/** Retrieves the fully qualified path for the file containing the specified module loaded by a given process.
Note GetModuleFileNameExW is a macro. */
template <typename string_type, size_t initialBufferLength = 128>
HRESULT GetModuleFileNameExW(_In_opt_ HANDLE process, _In_opt_ HMODULE module, string_type& path) WI_NOEXCEPT
{
    auto adapter = [&](_Out_writes_(valueLength) PWSTR value, size_t valueLength, _Out_ size_t* valueLengthNeededWithNul) -> HRESULT {
        DWORD copiedCount{};
        size_t valueUsedWithNul{};
        bool copyFailed{};
        bool copySucceededWithNoTruncation{};
        if (process != nullptr)
        {
            // GetModuleFileNameExW truncates and provides no error or other indication it has done so.
            // The only way to be sure it didn't truncate is if it didn't need the whole buffer. The
            // count copied to the buffer includes the nul-character as well.
            copiedCount = ::GetModuleFileNameExW(process, module, value, static_cast<DWORD>(valueLength));
            valueUsedWithNul = static_cast<size_t>(copiedCount) + 1;
            copyFailed = (0 == copiedCount);
            copySucceededWithNoTruncation = !copyFailed && (copiedCount < valueLength - 1);
        }
        else
        {
            // In cases of insufficient buffer, GetModuleFileNameW will return a value equal to lengthWithNull
            // and set the last error to ERROR_INSUFFICIENT_BUFFER. The count returned does not include
            // the nul-character
            copiedCount = ::GetModuleFileNameW(module, value, static_cast<DWORD>(valueLength));
            valueUsedWithNul = static_cast<size_t>(copiedCount) + 1;
            copyFailed = (0 == copiedCount);
            copySucceededWithNoTruncation = !copyFailed && (copiedCount < valueLength);
        }

        RETURN_LAST_ERROR_IF(copyFailed);

        // When the copy truncated, request another try with more space.
        *valueLengthNeededWithNul = copySucceededWithNoTruncation ? valueUsedWithNul : (valueLength * 2);

        return S_OK;
    };

    return wil::AdaptFixedSizeToAllocatedResult<string_type, initialBufferLength>(path, wistd::move(adapter));
}

/** Retrieves the fully qualified path for the file that contains the specified module.
The module must have been loaded by the current process. The path returned will use the same format that was specified when the
module was loaded. Therefore, the path can be a long or short file name, and can have the prefix '\\?\'. */
template <typename string_type, size_t initialBufferLength = 128>
HRESULT GetModuleFileNameW(HMODULE module, string_type& path) WI_NOEXCEPT
{
    return wil::GetModuleFileNameExW<string_type, initialBufferLength>(nullptr, module, path);
}

/** Retrieves the path of the Windows system directory, using `GetSystemDirectoryW`.
@tparam string_type The string type to produce the result in.
@tparam stackBufferLength The size, in characters, of the initial stack buffer.
@param result Receives the system directory path on success.
@return `S_OK` on success, or a failure `HRESULT`. */
template <typename string_type, size_t stackBufferLength = 256>
HRESULT GetSystemDirectoryW(string_type& result) WI_NOEXCEPT
{
    return wil::AdaptFixedSizeToAllocatedResult<string_type, stackBufferLength>(
        result, [&](_Out_writes_(valueLength) PWSTR value, size_t valueLength, _Out_ size_t* valueLengthNeededWithNul) -> HRESULT {
            *valueLengthNeededWithNul = ::GetSystemDirectoryW(value, static_cast<DWORD>(valueLength));
            RETURN_LAST_ERROR_IF(*valueLengthNeededWithNul == 0);
            if (*valueLengthNeededWithNul < valueLength)
            {
                (*valueLengthNeededWithNul)++; // it fit, account for the null
            }
            return S_OK;
        });
}

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)
/** Retrieves the path of the Windows directory, using `GetWindowsDirectoryW`.
@tparam string_type The string type to produce the result in.
@tparam stackBufferLength The size, in characters, of the initial stack buffer.
@param result Receives the Windows directory path on success.
@return `S_OK` on success, or a failure `HRESULT`. */
template <typename string_type, size_t stackBufferLength = 256>
HRESULT GetWindowsDirectoryW(string_type& result) WI_NOEXCEPT
{
    return wil::AdaptFixedSizeToAllocatedResult<string_type, stackBufferLength>(
        result, [&](_Out_writes_(valueLength) PWSTR value, size_t valueLength, _Out_ size_t* valueLengthNeededWithNul) -> HRESULT {
            *valueLengthNeededWithNul = ::GetWindowsDirectoryW(value, static_cast<DWORD>(valueLength));
            RETURN_LAST_ERROR_IF(*valueLengthNeededWithNul == 0);
            if (*valueLengthNeededWithNul < valueLength)
            {
                (*valueLengthNeededWithNul)++; // it fit, account for the null
            }
            return S_OK;
        });
}
#endif

#ifdef WIL_ENABLE_EXCEPTIONS
/** Expands the '%' quoted environment variables in 'input' using ExpandEnvironmentStringsW(); */
template <typename string_type = wil::unique_cotaskmem_string, size_t stackBufferLength = 256>
string_type ExpandEnvironmentStringsW(_In_ PCWSTR input)
{
    string_type result{};
    THROW_IF_FAILED((wil::ExpandEnvironmentStringsW<string_type, stackBufferLength>(input, result)));
    return result;
}

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)
/** Searches for a specified file in a specified path using SearchPathW. */
template <typename string_type = wil::unique_cotaskmem_string, size_t stackBufferLength = 256>
string_type TrySearchPathW(_In_opt_ PCWSTR path, _In_ PCWSTR fileName, PCWSTR _In_opt_ extension)
{
    string_type result{};
    HRESULT searchHR = wil::SearchPathW<string_type, stackBufferLength>(path, fileName, extension, result);
    THROW_HR_IF(searchHR, FAILED(searchHR) && (searchHR != HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND)));
    return result;
}
#endif

/** Looks up the environment variable 'key' and fails if it is not found. */
template <typename string_type = wil::unique_cotaskmem_string, size_t initialBufferLength = 128>
string_type GetEnvironmentVariableW(_In_ PCWSTR key)
{
    string_type result{};
    THROW_IF_FAILED((wil::GetEnvironmentVariableW<string_type, initialBufferLength>(key, result)));
    return result;
}

/** Looks up the environment variable 'key' and returns null if it is not found. */
template <typename string_type = wil::unique_cotaskmem_string, size_t initialBufferLength = 128>
string_type TryGetEnvironmentVariableW(_In_ PCWSTR key)
{
    string_type result{};
    THROW_IF_FAILED((wil::TryGetEnvironmentVariableW<string_type, initialBufferLength>(key, result)));
    return result;
}

/** Retrieves the fully qualified path for the file that contains the specified module.
Throws on failure. The module must have been loaded by the current process.
@tparam string_type The string type to return; defaults to `wil::unique_cotaskmem_string`.
@tparam initialBufferLength The size, in characters, of the initial stack buffer.
@param module The module to query, or `nullptr` for the current process's executable.
@return The module's fully qualified path. */
template <typename string_type = wil::unique_cotaskmem_string, size_t initialBufferLength = 128>
string_type GetModuleFileNameW(HMODULE module = nullptr /* current process module */)
{
    string_type result{};
    THROW_IF_FAILED((wil::GetModuleFileNameW<string_type, initialBufferLength>(module, result)));
    return result;
}

/** Retrieves the fully qualified path for the file containing the specified module loaded by a given process.
Throws on failure. Note `GetModuleFileNameExW` is a macro.
@tparam string_type The string type to return; defaults to `wil::unique_cotaskmem_string`.
@tparam initialBufferLength The size, in characters, of the initial stack buffer.
@param process The process that loaded the module, or `nullptr` to use the current process.
@param module The module to query, or `nullptr` for the process's executable.
@return The module's fully qualified path. */
template <typename string_type = wil::unique_cotaskmem_string, size_t initialBufferLength = 128>
string_type GetModuleFileNameExW(HANDLE process, HMODULE module)
{
    string_type result{};
    THROW_IF_FAILED((wil::GetModuleFileNameExW<string_type, initialBufferLength>(process, module, result)));
    return result;
}

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)
/** Retrieves the path of the Windows directory, using `GetWindowsDirectoryW`.
Throws on failure.
@tparam string_type The string type to return; defaults to `wil::unique_cotaskmem_string`.
@tparam stackBufferLength The size, in characters, of the initial stack buffer.
@return The Windows directory path. */
template <typename string_type = wil::unique_cotaskmem_string, size_t stackBufferLength = 256>
string_type GetWindowsDirectoryW()
{
    string_type result;
    THROW_IF_FAILED((wil::GetWindowsDirectoryW<string_type, stackBufferLength>(result)));
    return result;
}
#endif

/** Retrieves the path of the Windows system directory, using `GetSystemDirectoryW`.
Throws on failure.
@tparam string_type The string type to return; defaults to `wil::unique_cotaskmem_string`.
@tparam stackBufferLength The size, in characters, of the initial stack buffer.
@return The system directory path. */
template <typename string_type = wil::unique_cotaskmem_string, size_t stackBufferLength = 256>
string_type GetSystemDirectoryW()
{
    string_type result;
    THROW_IF_FAILED((wil::GetSystemDirectoryW<string_type, stackBufferLength>(result)));
    return result;
}

/** Retrieves the full path of the executable image for the specified process, using `QueryFullProcessImageNameW`.
Throws on failure.
@tparam string_type The string type to return; defaults to `wil::unique_cotaskmem_string`.
@tparam stackBufferLength The size, in characters, of the initial stack buffer.
@param processHandle A handle to the process; defaults to the current process.
@param flags Passed through to `QueryFullProcessImageNameW`; `0` for the Win32 path form or `PROCESS_NAME_NATIVE`.
@return The process image path. */
template <typename string_type = wil::unique_cotaskmem_string, size_t stackBufferLength = 256>
string_type QueryFullProcessImageNameW(HANDLE processHandle = GetCurrentProcess(), DWORD flags = 0)
{
    string_type result{};
    THROW_IF_FAILED((wil::QueryFullProcessImageNameW<string_type, stackBufferLength>(processHandle, flags, result)));
    return result;
}
#endif // WIL_ENABLE_EXCEPTIONS

#if WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)

/// @cond
namespace details
{
    // Lookup a DWORD value under HKLM\...\Image File Execution Options\<current process name>
    inline HRESULT GetCurrentProcessExecutionOptionNoThrow(PCWSTR valueName, DWORD defaultValue, DWORD* result)
    {
        *result = defaultValue;

        wil::unique_cotaskmem_string filePath;
        RETURN_IF_FAILED(wil::GetModuleFileNameW<wil::unique_cotaskmem_string>(nullptr, filePath));
        if (auto lastSlash = wcsrchr(filePath.get(), L'\\'))
        {
            const auto fileName = lastSlash + 1;
            wil::unique_cotaskmem_string keyPath;
            RETURN_IF_FAILED(wil::str_concat_nothrow<wil::unique_cotaskmem_string>(
                keyPath, LR"(SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\)", fileName));
            DWORD value{};
            DWORD sizeofValue = sizeof(value);
            if (::RegGetValueW(
                    HKEY_LOCAL_MACHINE,
                    keyPath.get(),
                    valueName,
#ifdef RRF_SUBKEY_WOW6464KEY
                    RRF_RT_REG_DWORD | RRF_SUBKEY_WOW6464KEY,
#else
                    RRF_RT_REG_DWORD,
#endif
                    nullptr,
                    &value,
                    &sizeofValue) == ERROR_SUCCESS)
            {
                *result = value;
            }
        }
        return S_OK;
    }
} // namespace details
/// @endcond

#ifdef WIL_ENABLE_EXCEPTIONS
/** Reads a DWORD "Image File Execution Options" value for the current process.
Throws on failure. Looks up `valueName` under `HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution
Options\<exe>`.
@param valueName The name of the `REG_DWORD` value to read.
@param defaultValue The value to return when the value is not present.
@return The configured value, or `defaultValue` if it is not set. */
inline DWORD GetCurrentProcessExecutionOption(PCWSTR valueName, DWORD defaultValue = 0)
{
    DWORD result{};
    THROW_IF_FAILED(details::GetCurrentProcessExecutionOptionNoThrow(valueName, defaultValue, &result));
    return result;
}
#endif // WIL_ENABLE_EXCEPTIONS

/** Reads a DWORD "Image File Execution Options" value for the current process, returning `defaultValue` on any failure (including
when the value is not set).
@param valueName The name of the `REG_DWORD` value to read.
@param defaultValue The value to return on failure or when the value is not present.
@return The configured value, or `defaultValue`. */
inline DWORD GetCurrentProcessExecutionOptionNoThrow(PCWSTR valueName, DWORD defaultValue = 0)
{
    DWORD result{};
    if (FAILED(details::GetCurrentProcessExecutionOptionNoThrow(valueName, defaultValue, &result)))
    {
        return defaultValue;
    }
    return result;
}

/** Reads a DWORD "Image File Execution Options" value for the current process, fail-fasting on failure.
@param valueName The name of the `REG_DWORD` value to read.
@param defaultValue The value to return when the value is not present.
@return The configured value, or `defaultValue` if it is not set. */
inline DWORD GetCurrentProcessExecutionOptionFailFast(PCWSTR valueName, DWORD defaultValue = 0)
{
    DWORD result{};
    FAIL_FAST_IF_FAILED(details::GetCurrentProcessExecutionOptionNoThrow(valueName, defaultValue, &result));
    return result;
}

#ifndef DebugBreak // Some code defines 'DebugBreak' to garbage to force build breaks in release builds
// Waits for a debugger to attach to the current process based on registry configuration.
//
// Example:
//     HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\explorer.exe
//         WaitForDebuggerPresent=1
//
// REG_DWORD value of
//     missing or 0 -> don't break
//     1 -> wait for the debugger, continue execution once it is attached
//     2 -> wait for the debugger, break here once attached.
/// @cond
namespace details
{
    template <typename error_policy>
    inline void WaitForDebuggerPresent(bool checkRegistryConfig)
    {
        for (;;)
        {
            DWORD configValue{1};
            if (checkRegistryConfig)
            {
                // err_returncode_policy will continue running after this line on failure.  The default value of zero
                // will apply in that case so we will still behave reasonably.
                error_policy::HResult(details::GetCurrentProcessExecutionOptionNoThrow(L"WaitForDebuggerPresent", 0, &configValue));
            }

            if (configValue == 0)
            {
                return; // not configured, don't wait
            }

            if (IsDebuggerPresent())
            {
                if (configValue == 2)
                {
                    DebugBreak(); // debugger attached, SHIFT+F11 to return to the caller
                }
                return; // debugger now attached, continue executing
            }
            Sleep(500);
        }
    }
} // namespace details
/// @endcond

#ifdef WIL_ENABLE_EXCEPTIONS
/** Waits for a debugger to attach to the current process, based on registry configuration.
Throws on failure. When `checkRegistryConfig` is `true`, the `WaitForDebuggerPresent` `REG_DWORD` value under this process's Image
File Execution Options key controls the behavior: missing or `0` returns immediately, `1` waits and then continues, and `2` waits
and then breaks into the debugger. When `false`, it unconditionally waits for a debugger to attach.
@param checkRegistryConfig `true` to honor the registry configuration, `false` to always wait. */
inline void WaitForDebuggerPresent(bool checkRegistryConfig = true)
{
    details::WaitForDebuggerPresent<err_exception_policy>(checkRegistryConfig);
}
#endif // WIL_ENABLE_EXCEPTIONS

/** Like `WaitForDebuggerPresent`, but never throws (uses the error-code policy internally).
@param checkRegistryConfig `true` to honor the registry configuration, `false` to always wait. */
inline void WaitForDebuggerPresentNoThrow(bool checkRegistryConfig = true)
{
    details::WaitForDebuggerPresent<err_returncode_policy>(checkRegistryConfig);
}

/** Like `WaitForDebuggerPresent`, but fail-fasts instead of throwing on failure.
@param checkRegistryConfig `true` to honor the registry configuration, `false` to always wait. */
inline void WaitForDebuggerPresentFailFast(bool checkRegistryConfig = true)
{
    details::WaitForDebuggerPresent<err_failfast_policy>(checkRegistryConfig);
}

#endif // DebugBreak
#endif // WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM)

/** Retrieve the HINSTANCE for the current DLL or EXE using this symbol that the linker provides for every module.
This avoids the need for a global HINSTANCE variable and provides access to this value for static libraries. */
inline HINSTANCE GetModuleInstanceHandle() WI_NOEXCEPT
{
    return reinterpret_cast<HINSTANCE>(&__ImageBase);
}

// GetModuleHandleExW was added to the app partition in version 22000 of the SDK
#if defined(NTDDI_WIN10_CO) ? WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_APP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES) \
                            : WINAPI_FAMILY_PARTITION(WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_SYSTEM | WINAPI_PARTITION_GAMES)
/** Keeps the current module loaded for the lifetime of a thread that may outlive the code that created it.
Call this at the very start of a thread procedure when the thread can outlive the object or API call that created it (for
example a thread started from a DLL that may be unloaded): without it, COM or the API caller can unload the DLL while the thread
is still running, resulting in a crash. It must be the first object created in the thread proc so that it is destroyed last; its
destructor calls `FreeLibraryAndExitThread`, which exits the thread and would otherwise skip the destructors of any objects
created before it.
~~~
DWORD WINAPI MyThreadProc(void*)
{
    // Must be the first object created in the thread proc.
    auto moduleRef = wil::get_module_reference_for_thread();

    DoWorkThatMayOutliveTheCaller();
    return 0; // moduleRef's destructor releases the module reference and exits the thread via FreeLibraryAndExitThread.
}

// The DLL that starts the thread may be unloaded before MyThreadProc finishes; the reference above keeps it loaded.
wil::unique_handle thread{::CreateThread(nullptr, 0, MyThreadProc, nullptr, 0, nullptr)};
~~~
@return A `wil::scope_exit` object that, when destroyed, calls `FreeLibraryAndExitThread` to release the module reference and
        exit the thread. */
[[nodiscard]] inline auto get_module_reference_for_thread() noexcept
{
    HMODULE thisModule{};
    FAIL_FAST_IF(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, L"", &thisModule));
    return wil::scope_exit([thisModule] {
        FreeLibraryAndExitThread(thisModule, 0);
    });
}
#endif

/// @cond
namespace details
{
    class init_once_completer
    {
        INIT_ONCE& m_once;
        unsigned long m_flags = INIT_ONCE_INIT_FAILED;

    public:
        init_once_completer(_In_ INIT_ONCE& once) WI_NOEXCEPT : m_once(once)
        {
        }

#pragma warning(push)
#pragma warning(disable : 4702) // https://github.com/Microsoft/wil/issues/2
        void success() WI_NOEXCEPT
        {
            m_flags = 0;
        }
#pragma warning(pop)

        ~init_once_completer() WI_NOEXCEPT
        {
            ::InitOnceComplete(&m_once, m_flags, nullptr);
        }
    };
} // namespace details
/// @endcond

/** Performs one-time initialization
Simplifies using the Win32 INIT_ONCE structure to perform one-time initialization. The provided `func` is invoked
at most once.
~~~~
INIT_ONCE g_init{};
ComPtr<IFoo> g_foo;
HRESULT MyMethod()
{
    bool winner = false;
    RETURN_IF_FAILED(wil::init_once_nothrow(g_init, []
    {
        ComPtr<IFoo> foo;
        RETURN_IF_FAILED(::CoCreateInstance(..., IID_PPV_ARGS(&foo));
        RETURN_IF_FAILED(foo->Startup());
        g_foo = foo;
    }, &winner);
    if (winner)
    {
        RETURN_IF_FAILED(g_foo->Another());
    }
    return S_OK;
}
~~~~
See MSDN for more information on `InitOnceExecuteOnce`.
@param initOnce The INIT_ONCE structure to use as context for initialization.
@param func A function that will be invoked to perform initialization. If this fails, the init call
        fails and the once-init is not marked as initialized. A later caller could attempt to
        initialize it a second time.
@param callerCompleted Set to 'true' if this was the call that caused initialization, false otherwise.
*/
template <typename T>
HRESULT init_once_nothrow(_Inout_ INIT_ONCE& initOnce, T func, _Out_opt_ bool* callerCompleted = nullptr) WI_NOEXCEPT
{
    BOOL pending = FALSE;
    wil::assign_to_opt_param(callerCompleted, false);

    __WIL_PRIVATE_RETURN_IF_WIN32_BOOL_FALSE(InitOnceBeginInitialize(&initOnce, 0, &pending, nullptr));

    if (pending)
    {
        details::init_once_completer completion(initOnce);
        __WIL_PRIVATE_RETURN_IF_FAILED(func());
        completion.success();
        wil::assign_to_opt_param(callerCompleted, true);
    }

    return S_OK;
}

//! Similar to init_once_nothrow, but fails-fast if the initialization step failed. The 'callerComplete' value is
//! returned to the caller instead of being an out-parameter.
template <typename T>
bool init_once_failfast(_Inout_ INIT_ONCE& initOnce, T&& func) WI_NOEXCEPT
{
    bool callerCompleted;

    FAIL_FAST_IF_FAILED(init_once_nothrow(initOnce, wistd::forward<T>(func), &callerCompleted));

    return callerCompleted;
};

//! Returns 'true' if this `init_once` structure has finished initialization, false otherwise.
inline bool init_once_initialized(_Inout_ INIT_ONCE& initOnce) WI_NOEXCEPT
{
    BOOL pending = FALSE;
    return ::InitOnceBeginInitialize(&initOnce, INIT_ONCE_CHECK_ONLY, &pending, nullptr) && !pending;
}

#ifdef WIL_ENABLE_EXCEPTIONS
/** Performs one-time initialization
Simplifies using the Win32 INIT_ONCE structure to perform one-time initialization. The provided `func` is invoked
at most once.
~~~~
INIT_ONCE g_init{};
ComPtr<IFoo> g_foo;
void MyMethod()
{
    bool winner = wil::init_once(g_init, []
    {
        ComPtr<IFoo> foo;
        THROW_IF_FAILED(::CoCreateInstance(..., IID_PPV_ARGS(&foo));
        THROW_IF_FAILED(foo->Startup());
        g_foo = foo;
    });
    if (winner)
    {
        THROW_IF_FAILED(g_foo->Another());
    }
}
~~~~
See MSDN for more information on `InitOnceExecuteOnce`.
@param initOnce The INIT_ONCE structure to use as context for initialization.
@param func A function that will be invoked to perform initialization. If this fails, the init call
        fails and the once-init is not marked as initialized. A later caller could attempt to
        initialize it a second time.
@returns 'true' if this was the call that caused initialization, false otherwise.
*/
template <typename T>
bool init_once(_Inout_ INIT_ONCE& initOnce, T func)
{
    BOOL pending = FALSE;

    THROW_IF_WIN32_BOOL_FALSE(::InitOnceBeginInitialize(&initOnce, 0, &pending, nullptr));

    if (pending)
    {
        details::init_once_completer completion(initOnce);
        func();
        completion.success();
        return true;
    }

    return false;
}
#endif // WIL_ENABLE_EXCEPTIONS

#if WIL_USE_STL && defined(WIL_ENABLE_EXCEPTIONS) && (__cpp_lib_string_view >= 201606L)
/// @cond
namespace details
{
    // NOTE: We can't have a 'using std::begin' at class scope, hence the workaround for handling both 'begin' with ADL
    // and 'std::begin' separately. We want to handle both because there's no guarantee the type has a 'begin' method
    template <typename RangeT>
    struct deduce_char_type_from_string_range_traits
    {
        template <typename U>
        static std::true_type deduce_has_adl_begin(U&& range, std::void_t<decltype((*begin(range))[0])>*);
        template <typename U>
        static std::false_type deduce_has_adl_begin(U&&, ...);

        template <typename U>
        static std::true_type deduce_has_std_begin(U&& range, std::void_t<decltype((*std::begin(range))[0])>*);
        template <typename U>
        static std::false_type deduce_has_std_begin(U&&, ...);

        static constexpr bool has_adl_begin = decltype(deduce_has_adl_begin(std::declval<RangeT>(), nullptr))::value;
        static constexpr bool has_std_begin = decltype(deduce_has_std_begin(std::declval<RangeT>(), nullptr))::value;
    };

    template <typename RangeT, bool hasAdlBegin = deduce_char_type_from_string_range_traits<RangeT>::has_adl_begin, bool hasStdBegin = deduce_char_type_from_string_range_traits<RangeT>::has_std_begin>
    struct deduce_char_type_from_string_range
    {
    };

    template <typename RangeT, bool hasStdBegin>
    struct deduce_char_type_from_string_range<RangeT, true, hasStdBegin>
    {
        using type = std::decay_t<decltype((*begin(std::declval<RangeT>()))[0])>;
    };

    template <typename RangeT>
    struct deduce_char_type_from_string_range<RangeT, false, true>
    {
        using type = std::decay_t<decltype((*std::begin(std::declval<RangeT>()))[0])>;
    };

    template <typename RangeT>
    using deduce_char_type_from_string_range_t = typename deduce_char_type_from_string_range<RangeT>::type;

    // Internal helper span-like type for passing arrays as an iterable collection
    template <typename T>
    struct iterable_span
    {
        T* pointer;
        size_t size;

        constexpr T* begin() const noexcept
        {
            return pointer;
        }

        constexpr T* end() const noexcept
        {
            return pointer + size;
        }
    };
} // namespace details
/// @endcond

//! Flags that control the behavior of `ArgvToCommandLine`
enum class ArgvToCommandLineFlags : uint8_t
{
    None = 0,

    //! By default, arguments are only surrounded by quotes when necessary (i.e. the argument contains a space). When
    //! this flag is specified, all arguments are surrounded with quotes, regardless of whether or not they contain
    //! space(s). This is an optimization as it means that we are not required to search for spaces in each argument and
    //! we don't need to potentially go back and insert a quotation character in the middle of the string after we've
    //! already written part of the argument to the result. That said, wrapping all arguments with quotes can have some
    //! adverse effects with some applications, most notably cmd.exe, which do their own command line processing.
    ForceQuotes = 0x01 << 0,

    //! `CommandLineToArgvW` has an "optimization" that assumes that the first argument is the path to an executable.
    //! Because valid NTFS paths cannot contain quotation characters, `CommandLineToArgvW` disables its quote escaping
    //! logic for the first argument. By default, `ArgvToCommandLine` aims to ensure that an argv array can "round trip"
    //! to a string and back, meaning it tries to replicate this logic in reverse. This flag disables this logic and
    //! escapes backslashes and quotes the same for all arguments, including the first one. This is useful if the output
    //! string is only an intermediate command line string (e.g. if the executable path is prepended later).
    FirstArgumentIsNotPath = 0x01 << 1,
};
DEFINE_ENUM_FLAG_OPERATORS(ArgvToCommandLineFlags);

//! Performs the reverse operation of CommandLineToArgvW.
//! Converts an argv array to a command line string that is guaranteed to "round trip" with CommandLineToArgvW. That is,
//! a call to wil::ArgvToCommandLine followed by a call to ArgvToCommandLineW will produce the same array that was
//! passed to wil::ArgvToCommandLine. Note that the reverse is not true. I.e. calling ArgvToCommandLineW followed by
//! wil::ArgvToCommandLine will not produce the original string due to the optionality of of quotes in the command line
//! string. This functionality is useful in a number of scenarios, most notably:
//!     1.  When implementing a "driver" application. That is, an application that consumes some command line arguments,
//!         translates others into new arguments, and preserves the rest, "forwarding" the resulting command line to a
//!         separate application.
//!     2.  When reading command line arguments from some data storage, e.g. from a JSON array, which then need to get
//!         compiled into a command line string that's used for creating a new process.
//! Unlike CommandLineToArgvW, this function accepts both "narrow" and "wide" strings to support calling both
//! CreateProcessW and CreateProcessA with the result. See the values in @ref wil::ArgvToCommandLineFlags for more
//! information on how to control the behavior of this function as well as scenarios when you may want to use each one.
template <typename RangeT, typename CharT = details::deduce_char_type_from_string_range_t<RangeT>>
inline std::basic_string<CharT> ArgvToCommandLine(RangeT&& range, ArgvToCommandLineFlags flags = ArgvToCommandLineFlags::None)
{
    using string_type = std::basic_string<CharT>;
    using string_view_type = std::basic_string_view<CharT>;

    // Somewhat of a hack to avoid the fact that we can't conditionalize a string literal on a template
    static constexpr const CharT empty_string[] = {'\0'};
    static constexpr const CharT single_quote_string[] = {'"', '\0'};
    static constexpr const CharT double_quote_string[] = {'"', '"', '\0'};
    static constexpr const CharT space_string[] = {' ', '\0'};
    static constexpr const CharT quoted_space_string[] = {'"', ' ', '"', '\0'};

    static constexpr const CharT search_string_no_space[] = {'\\', '"', '\0'};
    static constexpr const CharT search_string_with_space[] = {'\\', '"', ' ', '\t', '\0'};

    const bool forceQuotes = WI_IsFlagSet(flags, ArgvToCommandLineFlags::ForceQuotes);
    const CharT* const initialSearchString = forceQuotes ? search_string_no_space : search_string_with_space;
    const CharT* prefix = forceQuotes ? single_quote_string : empty_string;
    const CharT* const nextPrefix = forceQuotes ? quoted_space_string : space_string;

    string_type result;
    int index = 0;
    for (auto&& strRaw : range)
    {
        auto currentIndex = index++;
        result += prefix;
        prefix = nextPrefix;

        const CharT* searchString = initialSearchString;

        // Info just in case we need to come back and insert quotes
        auto startPos = result.size();
        bool terminateWithQuotes = false; // With forceQuotes == true, this is baked into the prefix

        // We need to escape any quotes and CONDITIONALLY any backslashes
        string_view_type str(strRaw);
        if (str.empty() && !forceQuotes)
        {
            // The argument is empty. If we want to preserve it in the command line string, we need to manually insert
            // a pair of quotes since normal parsing won't handle this case
            result.append(double_quote_string);
            continue;
        }

        size_t pos = 0;
        while (pos < str.size())
        {
            auto nextPos = str.find_first_of(searchString, pos);
            if ((nextPos != str.npos) && ((str[nextPos] == ' ') || (str[nextPos] == '\t')))
            {
                // Insert the quote now since we'll need to otherwise stomp over data we're about to write
                // NOTE: By updating the search string here, we don't need to worry about manually inserting the
                // character later since we'll just include it in our next iteration
                WI_ASSERT(!forceQuotes);               // Otherwise, shouldn't be part of our search string
                searchString = search_string_no_space; // We're already adding a quote; don't do it again
                result.insert(startPos, 1, '"');
                terminateWithQuotes = true;
            }

            result.append(str, pos, nextPos - pos);
            pos = nextPos;
            if (pos == str.npos)
            {
                break;
            }

            if (str[pos] == '"')
            {
                // Kinda easy case; just escape the quotes, *unless* this is the first argument and we assume a path
                if ((currentIndex > 0) || WI_IsFlagSet(flags, ArgvToCommandLineFlags::FirstArgumentIsNotPath))
                {
                    result.append({'\\', '"'}); // Escape case
                }
                else
                {
                    // Realistically, this likely signals a bug since paths cannot contain quotes. That said, the
                    // behavior of CommandLineToArgvW is to just preserve "interior" quotes, so we do that.
                    // NOTE: 'CommandLineToArgvW' treats "interior" quotes as terminating quotes when the executable
                    // path begins with a quote, even if the next character is not a space. This assert won't catch all
                    // of such issues as we may detect a space, and therefore the need to surround the argument with
                    // quotes, later in the string; this is best effort. Such arguments wouldn't be valid and are not
                    // representable anyway
                    WI_ASSERT((pos > 0) && !WI_IsFlagSet(flags, ArgvToCommandLineFlags::ForceQuotes) && !terminateWithQuotes);
                    result.push_back('"'); // Not escaping case
                }
                ++pos; // Skip past quote on next search
            }
            else if (str[pos] == '\\')
            {
                // More complex case... Only need to escape if followed by 0+ backslashes and then either a quote or
                // the end of the string and we're adding quotes
                nextPos = str.find_first_not_of(L'\\', pos);

                // NOTE: This is an optimization taking advantage of the fact that doing a double append of 1+
                // backslashes will be functionally equivalent to escaping each one. This copies all of the backslashes
                // once. We _might_ do it again later
                result.append(str, pos, nextPos - pos);

                // If this is the first argument and is being interpreted as a path, we never escape slashes
                if ((currentIndex == 0) && !WI_IsFlagSet(flags, ArgvToCommandLineFlags::FirstArgumentIsNotPath))
                {
                    pos = nextPos;
                    continue;
                }

                if ((nextPos != str.npos) && (str[nextPos] != L'"'))
                {
                    // Simplest case... don't need to escape when followed by a non-quote character
                    pos = nextPos;
                    continue;
                }

                // If this is the end of the string and we're not appending a quotation to the end, we're in the
                // same boat as the above where we don't need to escape
                if ((nextPos == str.npos) && !forceQuotes && !terminateWithQuotes)
                {
                    pos = nextPos;
                    continue;
                }

                // Otherwise, we need to escape all backslashes. See above; this can be done with another append
                result.append(str, pos, nextPos - pos);
                pos = nextPos;
                if (pos != str.npos)
                {
                    // Must be followed by a quote; make sure we escape it, too. NOTE: We should have already early
                    // exited if this argument is being interpreted as an executable path
                    WI_ASSERT(str[pos] == '"');
                    result.append({'\\', '"'});
                    ++pos;
                }
            }
            else
            {
                // Otherwise space, which we handled above
                WI_ASSERT((str[pos] == ' ') || (str[pos] == '\t'));
            }
        }

        if (terminateWithQuotes)
        {
            result.push_back('"');
        }
    }

    // NOTE: We optimize the force quotes case by including them in the prefix string. We're not appending a prefix
    // anymore, so we need to make sure we close off the string
    if (forceQuotes)
    {
        result.push_back(L'\"');
    }

    return result;
}

//! Overload of `ArgvToCommandLine` that accepts a C-style `argc`/`argv` pair (e.g. from `wmain`/`main`).
//! @tparam CharT The character type of the arguments (`wchar_t` or `char`).
//! @param argc The number of arguments in `argv`.
//! @param argv The array of argument strings to convert.
//! @param flags Flags that control quoting behavior. See @ref wil::ArgvToCommandLineFlags.
//! @return A command line string equivalent to the given arguments; see the primary `ArgvToCommandLine` overload.
template <typename CharT>
inline std::basic_string<wistd::remove_cv_t<CharT>> ArgvToCommandLine(
    int argc, CharT* const* argv, ArgvToCommandLineFlags flags = ArgvToCommandLineFlags::None)
{
    return ArgvToCommandLine(details::iterable_span<CharT* const>{argv, static_cast<size_t>(argc)}, flags);
}
#endif
} // namespace wil

/** Calls `GetProcAddress` with type safety for C++ clients, using the type information from the named function.
The return value is automatically cast to match the function prototype of the input function.
~~~
auto sendMail = GetProcAddressByFunctionDeclaration(hinstMAPI, MAPISendMailW);
if (sendMail)
{
    sendMail(0, 0, pmm, MAPI_USE_DEFAULT, 0);
}
~~~
@param hinst The module handle to look up the function in.
@param fn The (unqualified) name of the function whose declaration supplies the type to cast to. */
#define GetProcAddressByFunctionDeclaration(hinst, fn) (reinterpret_cast<decltype(::fn)*>(GetProcAddress(hinst, #fn)))

#endif // __WIL_WIN32_HELPERS_INCLUDED
