@echo off
setlocal
call "C:\CVRBuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
pushd "%~dp0deps\detours\src"
nmake /nologo /f Makefile
if errorlevel 1 exit /b 1
popd
if not exist "%~dp0build\include\detours" mkdir "%~dp0build\include\detours"
copy /y "%~dp0deps\detours\include\detours.h" "%~dp0build\include\detours\detours.h" >nul
if errorlevel 1 exit /b 1
msbuild "%~dp0build\ExplorerTAP.vcxproj" /p:Configuration=Release /p:Platform=x64 /m:2 /nologo /v:minimal
exit /b %errorlevel%
