# TranslucentTB 26340 compatibility patch - corresponding source

Upstream: https://github.com/TranslucentTB/TranslucentTB
Base: release 2026.2, d4636e4398 (GPL-3.0).
Only modified upstream file: source/ExplorerTAP/visualtreewatcher.cpp.
Fix: match the XAML island content using XamlRoot().Content() instead of assuming an immediate-parent layout.

The source directory contains the complete upstream source snapshot with the patch applied. deps contains the WIL headers and Detours source used for the repaired DLL, including their licenses. SDK headers and Microsoft compiler binaries are not redistributed.

On this computer, run build-local.cmd. It uses the installed VS 2022 Build Tools at C:\CVRBuildTools and Windows SDK 10.0.26100.0. The result is build/bin/ExplorerTAP.dll. On another development machine, change the vcvars64.bat location to the installed Visual Studio path. This recipe rebuilds only the repaired ExplorerTAP module; the application's standard build instructions are in source/CONTRIBUTING.md.

A local runtime self-check and double-display visual checks passed on Windows 26340.9750. Full reboot and all appearance modes were not tested. This is a local repair, not an official release.