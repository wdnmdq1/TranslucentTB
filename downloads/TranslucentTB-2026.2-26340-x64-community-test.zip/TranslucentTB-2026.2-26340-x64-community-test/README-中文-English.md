# 非官方测试版 / Unofficial community test build

## 中文：解决方案和用法

本包基于官方 TranslucentTB 2026.2 x64 便携版，仅替换重新编译的 ExplorerTAP.dll，并附带全新的通用透明配置。修复代码位于 PR #1376：
https://github.com/TranslucentTB/TranslucentTB/pull/1376

用于 Windows 11 x64；目前只在 Windows 内部版本 26340.9750、双显示器环境验证。它不是官方发布版，也不是 ARM64 或 Windows 10 安装包。

1. 将 ZIP 全部解压到一个普通文件夹，不要直接在压缩包里运行 EXE。
2. 从系统托盘退出所有正在运行的 TranslucentTB，包括微软商店原版。
3. 打开任务管理器，找到“Windows 资源管理器”，选择“重新启动”，让之前的任务栏模块卸载。任务栏和桌面会短暂消失后恢复；不要在资源管理器正在复制文件时执行这一步。
4. 在解压后的文件夹里运行 TranslucentTB.exe，选择托盘菜单里的 Clear（透明）外观。
5. 只运行一个版本。如果测试失败，退出测试版，重新启动 Windows 资源管理器，再运行原来的版本。

本包不修改注册表、不添加开机启动项，也不包含原作者以外任何人的个人设置备份。退出后应恢复任务栏原外观；切换回其他版本前仍需重新启动资源管理器以卸载 DLL。

## English: solution and usage

This package uses the official TranslucentTB 2026.2 x64 portable files, with only ExplorerTAP.dll replaced by the rebuilt module and a fresh generic Clear configuration added. Source change: PR #1376:
https://github.com/TranslucentTB/TranslucentTB/pull/1376

For Windows 11 x64. Tested only on Windows build 26340.9750 with two displays. This is an unofficial test build, not an ARM64 or Windows 10 installer.

1. Extract the entire ZIP to a normal folder. Do not run the EXE from inside the ZIP.
2. Exit every running instance of TranslucentTB from its tray menu, including the Microsoft Store version.
3. In Task Manager, select Windows Explorer and choose Restart to unload the previous taskbar module. The taskbar and desktop will disappear briefly. Do not do this during an Explorer file-copy operation.
4. Run TranslucentTB.exe from the extracted folder and select Clear in its tray appearance menu.
5. Run only one version at a time. To revert, exit this build, restart Windows Explorer, then launch the original version.

This package does not change registry values or add a startup entry. It contains no personal configuration backups. Restart Explorer before switching versions so the loaded DLL is unloaded.

## 验证范围 / Validation scope

- Release x64 ExplorerTAP module rebuilt on the official 2026.2 release source base.
- Transparency visually verified on both taskbars on Windows build 26340.9750.
- Clear, Acrylic and border visibility service calls succeeded on both taskbars; application restart succeeded.
- The bundled DLL is byte-for-byte identical to the locally tested module. The fresh public configuration was checked structurally; this repackaged ZIP has not been separately run on another computer.
- Not tested: full develop build/CI, full system reboot, other Windows builds or all appearance modes. The patch is not verified to fix the separately reported RPC_E_WRONG_THREAD error.

## 来源和许可证 / Source and license

Upstream: https://github.com/TranslucentTB/TranslucentTB/releases/tag/2026.2
Base source: d4636e439865df0a1a1419db408e055740ce5c74
Patch commit: https://github.com/wdnmdq1/TranslucentTB/commit/843136728b6979412b2b5617fbb07e7762267699
Complete corresponding source archive: TranslucentTB-2026.2-26340-fix-source.zip (shared alongside this package).

GPL-3.0 project license: LICENSE.md. Included open-source dependency notices: third-party-licenses/.
ExplorerTAP.dll is a locally compiled, unsigned repair module. This package is not an official signed release.
